export LESSOPEN='|/data/data/com.nobiterminal/files/usr/bin/lesspipe.sh %s'
