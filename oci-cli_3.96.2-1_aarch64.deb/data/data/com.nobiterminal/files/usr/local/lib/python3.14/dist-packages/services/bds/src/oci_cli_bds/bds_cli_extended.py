# coding: utf-8
# Copyright (c) 2016, 2021, Oracle and/or its affiliates.  All rights reserved.
# This software is dual-licensed to you under the Universal Permissive License (UPL) 1.0 as shown at https://oss.oracle.com/licenses/upl or Apache License 2.0 as shown at http://www.apache.org/licenses/LICENSE-2.0. You may choose either license.

from oci_cli import cli_util
from services.bds.src.oci_cli_bds.generated import bds_cli
from oci_cli import custom_types  # noqa: F401
from oci_cli import cli_constants  # noqa: F401
import click
from oci_cli.aliasing import CommandGroupWithAlias
from oci_cli import json_skeleton_utils


# oci bds work-request-log-entry list-work-request-logs -> oci bds work-request-log-entry list
cli_util.rename_command(bds_cli, bds_cli.work_request_log_entry_group, bds_cli.list_work_request_logs, 'list')


# oci bds bds-instance -> oci bds instance
cli_util.rename_command(bds_cli, bds_cli.bds_root_group, bds_cli.bds_instance_group, "instance")

cli_util.rename_command(bds_cli, bds_cli.bds_instance_group, bds_cli.remove_nodes, "remove-nodes")
cli_util.rename_command(bds_cli, bds_cli.bds_instance_group, bds_cli.remove_node, "remove")
cli_util.rename_command(bds_cli, bds_cli.bds_instance_group, bds_cli.bds_instance_reset_password, "reset-password")

# oci bds bds-instance add  -> oci bds instance worker-nodes add


@click.command('worker-nodes', cls=CommandGroupWithAlias, help=bds_cli.add_worker_nodes.help)
@cli_util.help_option_group
def bds_worker_nodes_group():
    pass


bds_cli.bds_instance_group.commands.pop(bds_cli.add_worker_nodes.name)
bds_cli.bds_instance_group.add_command(bds_worker_nodes_group)
bds_worker_nodes_group.add_command(bds_cli.add_worker_nodes)


# oci bds bds-instance add  -> oci bds instance master-nodes add
@click.command('master-nodes', cls=CommandGroupWithAlias, help=bds_cli.add_master_nodes.help)
@cli_util.help_option_group
def bds_master_nodes_group():
    pass


# bds_cli.bds_instance_group.commands.pop(bds_cli.add_master_nodes.name)
bds_cli.bds_instance_group.add_command(bds_master_nodes_group)
bds_master_nodes_group.add_command(bds_cli.add_master_nodes)


# oci bds bds-instance add  -> oci bds instance utility-nodes add
@click.command('utility-nodes', cls=CommandGroupWithAlias, help=bds_cli.add_utility_nodes.help)
@cli_util.help_option_group
def bds_utility_nodes_group():
    pass


# bds_cli.bds_instance_group.commands.pop(bds_cli.add_utility_nodes.name)
bds_cli.bds_instance_group.add_command(bds_utility_nodes_group)
bds_utility_nodes_group.add_command(bds_cli.add_utility_nodes)


# oci bds bds-instance add  -> oci bds kafka
# oci bds bds-instance remove  -> oci bds kafka
@click.command('kafka', cls=CommandGroupWithAlias, help='Kafka')
@cli_util.help_option_group
def bds_kafka_group():
    pass


bds_cli.bds_root_group.add_command(bds_kafka_group)
bds_kafka_group.add_command(bds_cli.add_kafka)
bds_kafka_group.add_command(bds_cli.remove_kafka)


# Add command: oci bds block-storage add
@click.command('block-storage', cls=CommandGroupWithAlias, help=bds_cli.add_block_storage.help)
@cli_util.help_option_group
def bds_block_storage_group():
    pass


bds_cli.bds_root_group.add_command(bds_block_storage_group)
bds_block_storage_group.add_command(bds_cli.add_block_storage)


# Add commands: oci bds cloudsql add | remove
@click.command('cloudsql', cls=CommandGroupWithAlias, help=bds_cli.add_cloud_sql.help)
@cli_util.help_option_group
def bds_cloud_sql_group():
    pass


bds_cli.bds_root_group.add_command(bds_cloud_sql_group)
bds_cloud_sql_group.add_command(bds_cli.add_cloud_sql)
bds_cloud_sql_group.add_command(bds_cli.remove_cloud_sql)


# Add command: oci bds auto-scaling-config create | delete | get | edit | list
@click.command('auto-scale-config', cls=CommandGroupWithAlias, help=bds_cli.add_auto_scaling_configuration.help)
@cli_util.help_option_group
def bds_auto_scaling_group():
    pass


bds_cli.bds_root_group.add_command(bds_auto_scaling_group)
bds_auto_scaling_group.add_command(bds_cli.add_auto_scaling_configuration)
cli_util.rename_command(bds_cli, bds_auto_scaling_group, bds_cli.add_auto_scaling_configuration, "create")
bds_auto_scaling_group.add_command(bds_cli.remove_auto_scaling_configuration)
cli_util.rename_command(bds_cli, bds_auto_scaling_group, bds_cli.remove_auto_scaling_configuration, "delete")
bds_cli.bds_instance_group.commands.pop(bds_cli.get_auto_scaling_configuration.name)
bds_auto_scaling_group.add_command(bds_cli.get_auto_scaling_configuration)
cli_util.rename_command(bds_cli, bds_auto_scaling_group, bds_cli.get_auto_scaling_configuration, "get")
bds_cli.bds_instance_group.commands.pop(bds_cli.update_auto_scaling_configuration.name)
bds_auto_scaling_group.add_command(bds_cli.update_auto_scaling_configuration)
cli_util.rename_command(bds_cli, bds_auto_scaling_group, bds_cli.update_auto_scaling_configuration, "edit")
bds_cli.bds_instance_group.commands.pop(bds_cli.list_auto_scaling_configurations.name)
bds_auto_scaling_group.add_command(bds_cli.list_auto_scaling_configurations)
cli_util.rename_command(bds_cli, bds_auto_scaling_group, bds_cli.list_auto_scaling_configurations, "list")


@cli_util.copy_params_from_generated_command(bds_cli.install_patch, params_to_exclude=['version_parameterconflict'])
@bds_cli.bds_instance_group.command(name=bds_cli.install_patch.name, help=bds_cli.install_patch.help)
@cli_util.option('--patch-version', required=True, help=u"""The version of the patch to be installed. [required]""")
@click.pass_context
@json_skeleton_utils.json_skeleton_generation_handler(input_params_to_complex_types={})
@cli_util.wrap_exceptions
def install_patch_extended(ctx, **kwargs):
    if 'patch_version' in kwargs:
        kwargs['version_parameterconflict'] = kwargs['patch_version']
        kwargs.pop('patch_version')

    ctx.invoke(bds_cli.install_patch, **kwargs)


# Remove add-auto-scaling-configuration-add-metric-based-horizontal-scaling-policy-details from oci bds instance
bds_cli.bds_instance_group.commands.pop(bds_cli.add_auto_scaling_configuration_add_metric_based_horizontal_scaling_policy_details.name)


# Remove add-auto-scaling-configuration-add-metric-based-vertical-scaling-policy-details from oci bds instance
bds_cli.bds_instance_group.commands.pop(bds_cli.add_auto_scaling_configuration_add_metric_based_vertical_scaling_policy_details.name)


# Remove add-auto-scaling-configuration-add-schedule-based-horizontal-scaling-policy-details from oci bds instance
bds_cli.bds_instance_group.commands.pop(bds_cli.add_auto_scaling_configuration_add_schedule_based_horizontal_scaling_policy_details.name)


# Remove add-auto-scaling-configuration-add-schedule-based-vertical-scaling-policy-details from oci bds instance
bds_cli.bds_instance_group.commands.pop(bds_cli.add_auto_scaling_configuration_add_schedule_based_vertical_scaling_policy_details.name)


# Remove update-auto-scaling-configuration-update-metric-based-horizontal-scaling-policy-details from oci bds instance
bds_cli.bds_instance_group.commands.pop(bds_cli.update_auto_scaling_configuration_update_metric_based_horizontal_scaling_policy_details.name)


# Remove update-auto-scaling-configuration-update-metric-based-vertical-scaling-policy-details from oci bds instance
bds_cli.bds_instance_group.commands.pop(bds_cli.update_auto_scaling_configuration_update_metric_based_vertical_scaling_policy_details.name)


# Remove update-auto-scaling-configuration-update-schedule-based-horizontal-scaling-policy-details from oci bds instance
bds_cli.bds_instance_group.commands.pop(bds_cli.update_auto_scaling_configuration_update_schedule_based_horizontal_scaling_policy_details.name)


# Remove update-auto-scaling-configuration-update-schedule-based-vertical-scaling-policy-details from oci bds instance
bds_cli.bds_instance_group.commands.pop(bds_cli.update_auto_scaling_configuration_update_schedule_based_vertical_scaling_policy_details.name)


@cli_util.copy_params_from_generated_command(bds_cli.install_patch_batching_based_odh_patching_config, params_to_exclude=['version_parameterconflict'])
@bds_cli.bds_instance_group.command(name=bds_cli.install_patch_batching_based_odh_patching_config.name, help=bds_cli.install_patch_batching_based_odh_patching_config.help)
@cli_util.option('--patch-version', required=True, help=u"""The version of the patch to be installed. [required]""")
@click.pass_context
@json_skeleton_utils.json_skeleton_generation_handler(input_params_to_complex_types={})
@cli_util.wrap_exceptions
def install_patch_batching_based_odh_patching_config_extended(ctx, **kwargs):

    if 'patch_version' in kwargs:
        kwargs['version_parameterconflict'] = kwargs['patch_version']
        kwargs.pop('patch_version')

    ctx.invoke(bds_cli.install_patch_batching_based_odh_patching_config, **kwargs)


@cli_util.copy_params_from_generated_command(bds_cli.install_patch_domain_based_odh_patching_config, params_to_exclude=['version_parameterconflict'])
@bds_cli.bds_instance_group.command(name=bds_cli.install_patch_domain_based_odh_patching_config.name, help=bds_cli.install_patch_domain_based_odh_patching_config.help)
@cli_util.option('--patch-version', required=True, help=u"""The version of the patch to be installed. [required]""")
@click.pass_context
@json_skeleton_utils.json_skeleton_generation_handler(input_params_to_complex_types={})
@cli_util.wrap_exceptions
def install_patch_domain_based_odh_patching_config_extended(ctx, **kwargs):

    if 'patch_version' in kwargs:
        kwargs['version_parameterconflict'] = kwargs['patch_version']
        kwargs.pop('patch_version')

    ctx.invoke(bds_cli.install_patch_domain_based_odh_patching_config, **kwargs)


@cli_util.copy_params_from_generated_command(bds_cli.install_patch_downtime_based_odh_patching_config, params_to_exclude=['version_parameterconflict'])
@bds_cli.bds_instance_group.command(name=bds_cli.install_patch_downtime_based_odh_patching_config.name, help=bds_cli.install_patch_downtime_based_odh_patching_config.help)
@cli_util.option('--patch-version', required=True, help=u"""The version of the patch to be installed. [required]""")
@click.pass_context
@json_skeleton_utils.json_skeleton_generation_handler(input_params_to_complex_types={})
@cli_util.wrap_exceptions
def install_patch_downtime_based_odh_patching_config_extended(ctx, **kwargs):

    if 'patch_version' in kwargs:
        kwargs['version_parameterconflict'] = kwargs['patch_version']
        kwargs.pop('patch_version')

    ctx.invoke(bds_cli.install_patch_downtime_based_odh_patching_config, **kwargs)
