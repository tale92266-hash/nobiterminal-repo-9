/**
 * @license
 * Copyright 2013 The Emscripten Authors
 * SPDX-License-Identifier: MIT
 *
 * This file gets implicitly injected as a `--pre-js` file when
 * emcc is run with `--emrun`
 */

// Route URL GET parameters to argc+argv
if (globalThis.window) {
  Module['arguments'] = window.location.search.slice(1).trim().split('&');
  for (let i = 0; i < Module['arguments'].length; ++i) {
    Module['arguments'][i] = decodeURI(Module['arguments'][i]);
  }
  // If no args were passed arguments = [''], in which case kill the single empty string.
  if (!Module['arguments'][0]) {
    Module['arguments'] = [];
  }
}
