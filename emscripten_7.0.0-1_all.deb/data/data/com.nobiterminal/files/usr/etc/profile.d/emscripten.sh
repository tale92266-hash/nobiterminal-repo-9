#!/data/data/com.nobiterminal/files/usr/bin/sh
export PATH=${PATH}:/data/data/com.nobiterminal/files/usr/opt/emscripten
