export NEXT_TEST_WASM_DIR=/dev/null
export NEXT_TEST_NATIVE_DIR=/data/data/com.nobiterminal/files/usr/lib/node_modules/@next/swc-android-arm64
